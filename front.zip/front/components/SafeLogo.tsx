//Safe Alert - Hackathon ETHCC5
export default function SafeLogo() {
    return (
        <img 
        width="80"
        height="80"
        src="logo_safe_alert.png"></img>
    );}