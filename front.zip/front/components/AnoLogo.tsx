//Safe Alert - Hackathon ETHCC5
export default function SafeLogo() {
    return (
        <img 
        width="300"
        height="350"
        src="anonymous.png"></img>
    );}