export const PRIVY_API_KEY = process.env.NEXT_PUBLIC_PRIVY_API_KEY as string;
